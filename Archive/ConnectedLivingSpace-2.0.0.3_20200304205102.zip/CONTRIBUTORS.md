Connected Living Spaces - Contributors
======================================

These are the people who contributed towards the Connected Living Spaces mod, in alphabetical order.  Core contributors are highlighted.

If you have contributed and are missing from this list, please contact the current maintainer.

 - Booots
 - cake-pie
 - **Codepoet** (original developer)
 - CRL42
 - JPLRepo
 - Kerbas_ad_astra
 - linuxgurugamer
 - *Micha* (current maintainer)
 - Mine_Turtle
 - **Papa_Joe** (long-term maintainer)
 - taniwha
 - tyehle
 - wookieegoldberg
 - yalov
